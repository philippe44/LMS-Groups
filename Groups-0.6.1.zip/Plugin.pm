use strict;

package Plugins::Groups::Plugin;

use base qw(Slim::Plugin::Base);

use Socket;
use List::Util qw(first);
use Data::Dump qw(dump);

use Slim::Utils::Strings qw (string);
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Player::StreamingController;

use Plugins::Groups::StreamingController qw(TRACK_END USER_STOP USER_PAUSE);

# override default Slim::Player::Source::playmode()
use Plugins::Groups::Source;
# override default Slim::Player::Playlist::stopAndClear()
use Plugins::Groups::Playlist;

my $log = Slim::Utils::Log->addLogCategory({
	'category' => 'plugin.groups',
	'defaultLevel' => 'ERROR',
	'description' => 'PLUGIN_GROUPS_NAME'
});

my $prefs = preferences('plugin.groups');
my $sprefs = preferences('server');
my $originalVolumeHandler;
my $originalSyncHandler;

$prefs->init({
	# can't set prefs at a true value for checkboxes (unchecked = undef)
	# restoreStatic => 1,
	showDisconnected => 0,
	breakupTimeout => 30,
});


# migrate existing prefs to new structure, bump prefs version by one tick
# XXX - this code can probably be removed - only needed for beta testers
$prefs->migrate(3, sub {
	my @migrate = ( 'powerMaster', 'powerPlay', 'members', 'volumes' );

	foreach my $client ($sprefs->allClients) {
		next unless $client->exists($prefs->namespace);
		my $cprefs = Slim::Utils::Prefs::Client->new( $prefs, $client->{clientid}, 'no-migrate' );
		my $data = $client->get($prefs->namespace);
		foreach my $key (@migrate) { 
			$cprefs->set($key, $data->{$key});
		}	
		$client->remove($prefs->namespace);
	}
});

sub getDisplayName() {
	return 'PLUGIN_GROUPS_NAME';
}

sub initPlugin {
	my $class = shift;
	
	main::INFOLOG && $log->is_info && $log->info(string('PLUGIN_GROUPS_STARTING'));
	
	$prefs->set('restoreStatic', 1) unless $prefs->exits('restoreStatic');

	if ( main::WEBUI ) {
		require Plugins::Groups::Settings;
		Plugins::Groups::Settings->new;
		
		# try to add the Group Player section in the player selection drop-down menu - requires a recent 7.9.1 or later
		eval {
			require Slim::Web::Pages::JS;

			Slim::Web::Pages->addPageFunction("plugins/groups/js-main-grouping.js", sub {
				Slim::Web::HTTP::filltemplatefile('js-main-grouping.js', $_[1]);
			});
			
			Slim::Web::Pages::JS->addJSFunction('js-main', 'plugins/groups/js-main-grouping.js');		
		}
	}

	$class->initCLI();
		
	foreach my $id ( $class->groupIDs() ) {
		main::INFOLOG && $log->is_info && $log->info("Creating player group $id");
		createPlayer($id);
	}
	
	$originalVolumeHandler = Slim::Control::Request::addDispatch(['mixer', 'volume', '_newvalue'], [1, 0, 0, \&mixerVolumeCommand]);
	$originalSyncHandler = Slim::Control::Request::addDispatch(['sync', '_indexid-'], [1, 0, 1, \&syncCommand]);
}

sub doTransfer {
	my ($source, $dest) = @_;
			
	# need to preserve song index and seek data
	my $seekdata = $source->controller->playingSong->getSeekData($source->controller->playingSongElapsed);
	my $index = $source->controller->playingSong->index;
	
	# stop the destination and grab playlist from source	
	$dest->controller->stop;
	Slim::Player::Playlist::copyPlaylist($dest, $source);
				
	# start group player, it should assemble itself
	$dest->controller->play($index, $seekdata);
	Slim::Control::Request::notifyFromArray($dest, ['playlist', 'play']);
	Slim::Control::Request::notifyFromArray($dest, ['playlist', 'sync']);
	
	$source->controller->stop;
	Slim::Control::Request::notifyFromArray($source, ['playlist', 'stop']);
	Slim::Control::Request::notifyFromArray($source, ['playlist', 'sync']);
}

sub syncTimer {
	my $client = shift;
	my $slave = $client->pluginData('transfer');
	
	main::INFOLOG && $log->info("transfer timeout ", $client->id);
	return unless $slave;
	
	$client->pluginData(transfer => undef);
	$client->controller->sync($slave) unless $slave->isa("Plugins::Groups::Player");
}

sub syncCommand {
	my $request = shift;
	my $client  = $request->client;
	my $id = $request->getParam('_indexid-');
	my $slave = Slim::Player::Client::getClient($id) if $id !~ /-/;
	
	# make sure Group players are involved
	if (!$client->isa("Plugins::Groups::Player") && 
	    (!$slave || !$slave->isa("Plugins::Groups::Player")) && 
		!$client->pluginData('transfer')) {
		
		main::DEBUGLOG && $log->debug("nothing to process");
		$originalSyncHandler->($request);
		return;
	}
	
	main::DEBUGLOG && $log->debug("sync handler for groups", dump($request));
			
	if ($id !~ /-/) {
		# mark the player receiving sync so that we can do the transfer 
		# if/when the unsync is received for that player
		main::INFOLOG && $log->info("marking player ", $client->id, " for transfer to ", $slave->id);
		$client->pluginData(transfer => $slave);
		
		# this is a transfer, so it should be done super quickly, otherwise 
		# it's a user attempt that shall be process normally. The streaming
		# controller will reject if not valid (member of the group ...)
		Slim::Utils::Timers::setTimer($client, time() + 3, \&syncTimer);
	} elsif ($slave = $client->pluginData('transfer')) {
		# if the player is marked, then do the transfer
		Slim::Utils::Timers::killTimers($client, \&syncTimer);		
		main::INFOLOG && $log->info("transferring from ", $client->id, " to ", $slave->id);
		$client->pluginData(transfer => undef);
		doTransfer($client, $slave);
	} else {
		$log->error("don't know what we're doing here ", $client->id);
	}
	
	$request->setStatusDone;	
}

sub mixerVolumeCommand {
	my $request = shift;
    my $client  = $request->client;
	my $entity   = $request->getRequest(1);
	my $newVolume = $request->getParam('_newvalue');
	my $master = $client->controller->master;
		
	return $originalVolumeHandler->($request) unless $client->controller->isa("Plugins::Groups::StreamingController") &&
													 !$master->_volumeDispatching;
	
	my $members = $prefs->client($master)->get('members');	
	return $originalVolumeHandler->($request) unless scalar @$members;
	
	my $oldVolume = $client->volume;
	$newVolume += $oldVolume if $newVolume =~ /^[\+\-]/;
	
	# avoid recursing loop				
	$master->_volumeDispatching(1);			
	
	# get the memorized individual volumes
	my $volumes = $prefs->client($master)->get('volumes');
		
	main::INFOLOG && $log->is_info && $log->info("volume command $newVolume for $client with old volume $oldVolume (master = $master)");
	
	if ($client == $master) {
		# when changing virtual player's volume, apply a ratio to all members, 
		# whether they are currently sync'd or not (except the missing ones)
		foreach my $id (@$members) {
			# bypass fixed volumes (can't use getClient as it only works for connected devices)
			next if $volumes->{$id} == -1;
			my $volume = $oldVolume ? $volumes->{$id} * $newVolume / $oldVolume : $newVolume;
	
			$volumes->{$id} = $volume;
						
			main::DEBUGLOG && $log->is_debug && $log->debug("new volume for $id $volume");
			
			# only apply if member is connected & synchronized 
			my $member = Slim::Player::Client::getClient($id);
			Slim::Control::Request::executeRequest($member, ['mixer', 'volume', $volume]) if $member && $master->isSyncedWith($member);
		}	
	} else {
		# memorize volume in master's prefs 
		$volumes->{$client->id} = $sprefs->client($client)->get("digitalVolumeControl") ? $newVolume : -1;
		my $masterVolume = 0;
		my $count = 0;
		
		# the virtual is an average of all members' volumes
		foreach my $id (@$members) { 
			# do not take into account fixed volume members 
			next if $volumes->{$id} == -1; 
			
			# do not use actual $member->volume as we might not be actually synced with it
			$masterVolume += $volumes->{$id};
			$count++;
			main::DEBUGLOG && $log->is_debug && $log->debug("current volume of $id ", $volumes->{$id});
		}
		
		$masterVolume = $count ? $masterVolume / $count : -1;
				
		main::INFOLOG && $log->is_info && $log->info("setting master volume from $client for $master at $masterVolume");
	
		Slim::Control::Request::executeRequest($master, ['mixer', 'volume', $masterVolume]) if $masterVolume != -1;
	}

	# memorize volumes for when group will be re-assembled
	$prefs->client($master)->set('volumes', $volumes);
	
	# all dispatch done
	$master->_volumeDispatching(0);	
	
	$originalVolumeHandler->($request);
}

sub initVolume {
	my $master = Slim::Player::Client::getClient($_[0]);
	
	return unless $master;
	
	my $masterVolume = 0;
	my $members = $prefs->client($master)->get('members');
	my $volumes = $prefs->client($master)->get('volumes');
		
	return unless scalar @$members;
	
	my $count = 0;
	
	foreach my $id (@$members) {
		my $member = Slim::Player::Client::getClient($id);
		
		# do no take into account 100% fixed volume
		if ($sprefs->client($member)->get('digitalVolumeControl')) {
			# initialize member's volume if possible & needed	
			$count++;
			$volumes->{$id} = $member->volume if defined $member && !defined $volumes->{$id};
			$masterVolume += $volumes->{$id};
		} else { 
			$volumes->{$id} = -1; 
		}	
	}
	
	$prefs->client($master)->set('volumes', $volumes);	
	
	# set master's volume, if none abitrary set at 100%
	$masterVolume = $count ? $masterVolume / $count : 100;
	main::INFOLOG && $log->is_info && $log->info("new master volume $masterVolume");
	
	# this is init, so avoid loop in mixercommand (and can't rely on _volumeDispatching)
	$master->volume($masterVolume);
	$sprefs->client($master)->set('volume', $masterVolume);
	Slim::Control::Request::executeRequest($master, ['mixer', 'volume', $masterVolume]);
}

sub createPlayer {
	my ($id, $name) = @_;
	# need to have a fake socket because getClient does not call ipport() in an OoO way
	my $s = sockaddr_in(0, INADDR_LOOPBACK);

	# $id, $paddr, $rev, $s, $deviceid, $uuid
	my $client = Plugins::Groups::Player->new($id, $s, 1.0, undef, 12, undef);
	my $display_class = 'Slim::Display::NoDisplay';
	
	Slim::bootstrap::tryModuleLoad($display_class);

	if ($@) {
		$log->logBacktrace;
		$log->logdie("FATAL: Couldn't load module: $display_class: [$@]");
	}

	$client->display( $display_class->new($client) );
	$client->macaddress($id);
	$client->name($name);
	$client->tcpsock(1);
	$client->init;
		
	main::INFOLOG && $log->is_info && $log->info("create group player $client");
}

sub delPlayer {	
	my $client = Slim::Player::Client::getClient($_[0]);
	
	# remove client prefs as it will not come back with same mac
	$sprefs->remove($Slim::Utils::Prefs::Client::clientPreferenceTag . ':' . $_[0]);

	$client->tcpsock(undef);
	$client->disconnected(1);
		
	Slim::Control::Request::notifyFromArray($client, ['client', 'disconnect']);
	Slim::Utils::Timers::setTimer( $client,	Time::HiRes::time() + 5, sub {
				# $client->forgetClient;
				Slim::Control::Request::executeRequest($client, ['client', 'forget']);
				} );
				
	main::INFOLOG && $log->is_info && $log->info("delete group player $client");
}

sub initCLI {
	#                                                            |requires Client
	#                                                            |  |is a Query
	#                                                            |  |  |has Tags
	#                                                            |  |  |  |Function to call
	#                                                            C  Q  T  F
	Slim::Control::Request::addDispatch(['playergroups', '_index', '_quantity'],
	                                                            [0, 1, 0, \&_cliGroups]
	);

	Slim::Control::Request::addDispatch(['playergroup'],        [1, 1, 0, \&_cliGroup]);
}

sub _cliGroups {
	my $request = shift;

	# check this is the correct query.
	if ($request->isNotQuery([['playergroups']])) {
		$request->setStatusBadDispatch();
		return;
	}
	
	my $index    = $request->getParam('_index') || 0;
	my $quantity = $request->getParam('_quantity') || 10;

	my @groups = sort groupIDs();
	my $count = @groups;
	
	my ($valid, $start, $end) = $request->normalize(scalar($index), scalar($quantity), $count);
	
	$request->addResult('count', $count);
		
	my $loopname = 'groups_loop';
	my $chunkCount = 0;
	
	foreach my $group ( @groups[$start .. $end] ) {
		my $groupClient = Slim::Player::Client::getClient($group);
		
		$request->addResultLoop($loopname, $chunkCount, 'id', $group);				
		$request->addResultLoop($loopname, $chunkCount, 'name', $groupClient->name);
		$request->addResultLoop($loopname, $chunkCount, 'powerMaster', $prefs->client($groupClient)->get('powerMaster'));
		$request->addResultLoop($loopname, $chunkCount, 'powerPlay', $prefs->client($groupClient)->get('powerPlay'));
		$request->addResultLoop($loopname, $chunkCount, 'players', scalar @{ $prefs->client($groupClient)->get('members') || [ ]});
		
		$chunkCount++;
	}

	$request->setStatusDone();
}

sub _cliGroup {
	my $request = shift;

	# check this is the correct query.
	if ($request->isNotQuery([['playergroup']])) {
		$request->setStatusBadDispatch();
		return;
	}

	my $client = $request->client;
	
	if (!$client || $client->model ne 'group') {
		$log->warn($client->id . ' is either not a group, or it does not exist') if $client;
		$request->setStatusBadDispatch();
		return;
	}
	
	$request->addResult('name', $client->name);
	$request->addResult('powerMaster', $prefs->client($client)->get('powerMaster'));
	$request->addResult('powerPlay', $prefs->client($client)->get('powerPlay'));
	
	my $loopname = 'players_loop';
	my $chunkCount = 0;
	
	foreach my $player ( @{ $prefs->client($client)->get('members') || [] } ) {
		$request->addResultLoop($loopname, $chunkCount, 'id', $player);

		if ( my $member = Slim::Player::Client::getClient($player) ) {
			$request->addResultLoop($loopname, $chunkCount, 'playername', $member->name);
		}		
		$chunkCount++;
	}

	$request->setStatusDone();
}

sub allPrefs {
	return map { {clientid => $_->{clientid}, %{$_->all}} } $prefs->allClients;
}
		
sub groupIDs {
	return map { $_->{clientid} } $prefs->allClients;
}


1;
